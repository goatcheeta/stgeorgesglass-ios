define( function ( require ) {

	"use strict";

	return {
		app_slug : 'st-georges-glass-2',
		wp_ws_url : 'http://localhost/glassmob/wp-appkit-api/st-georges-glass-2',
		wp_url : 'http://localhost/glassmob',
		theme : 'q-ios',
		version : '5',
		app_type : 'phonegap-build',
		app_title : 'St. George\'s Glass',
		app_platform : 'ios',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : 'GtuXN@8BY!Q=cQ5`Q#$a8/X%h8Dy[uK&Mg)`yWLXArjp/}zHuEs4!]h.^o!U?;NN',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
